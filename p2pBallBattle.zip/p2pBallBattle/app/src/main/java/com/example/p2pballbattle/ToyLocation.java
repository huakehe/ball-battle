package com.example.p2pballbattle;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class ToyLocation {
    public ArrayList<Integer> target_x_list = new ArrayList<>();
    public ArrayList<Integer> target_y_list = new ArrayList<>();
    public ArrayList<Integer> trap_x_list = new ArrayList<>();
    public ArrayList<Integer> trap_y_list = new ArrayList<>();

    public ToyLocation(ArrayList<Integer> target_x_list, ArrayList<Integer> target_y_list, ArrayList<Integer> trap_x_list, ArrayList<Integer> trap_y_list) {
        this.target_x_list = target_x_list;
        this.target_y_list = target_y_list;
        this.trap_x_list = trap_x_list;
        this.trap_y_list = trap_y_list;
    }


    @Exclude
    public Map<String, Object> toToyMap() {
        // To map function to setup key/values for JSON tree in database
        HashMap<String, Object> result = new HashMap<>();
        result.put("target_x_list",target_x_list);
        result.put("target_y_list",target_y_list);
        result.put("trap_x_list",trap_x_list);
        result.put("trap_y_list",trap_y_list);
        return result;
    }

    public ToyLocation(){};

    public void setTarget_x_list(ArrayList<Integer> target_x_list) {
        this.target_x_list = target_x_list;
    }

    public void setTarget_y_list(ArrayList<Integer> target_y_list) {
        this.target_y_list = target_y_list;
    }

    public void setTrap_x_list(ArrayList<Integer> trap_x_list) {
        this.trap_x_list = trap_x_list;
    }

    public void setTrap_y_list(ArrayList<Integer> trap_y_list) {
        this.trap_y_list = trap_y_list;
    }

    public ArrayList<Integer> getTarget_x_list() {
        return target_x_list;
    }

    public ArrayList<Integer> getTarget_y_list() {
        return target_y_list;
    }

    public ArrayList<Integer> getTrap_x_list() {
        return trap_x_list;
    }

    public ArrayList<Integer> getTrap_y_list() {
        return trap_y_list;
    }
}