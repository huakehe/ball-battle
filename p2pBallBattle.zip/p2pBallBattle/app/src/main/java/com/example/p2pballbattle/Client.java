package com.example.p2pballbattle;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class Client {

    private float client_x;
    private float client_y;

    public Client(float client_x, float client_y) {
        this.client_x = client_x;
        this.client_y = client_y;
    }

    public Client(){}

    public float getClient_x() {
        return client_x;
    }

    public void setClient_x(float client_x) {
        this.client_x = client_x;
    }

    public float getClient_y() {
        return client_y;
    }

    public void setClient_y(float client_y) {
        this.client_y = client_y;
    }

    @Exclude
    public Map<String, Object> toClientMap() {
        // To map function to setup key/values for JSON tree in database
        HashMap<String, Object> result = new HashMap<>();
        result.put("client_x", client_x);
        result.put("client_y", client_y);

        return result;
    }

}
