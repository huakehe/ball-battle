package com.example.p2pballbattle;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class settings extends AppCompatActivity {

    int bg_number;
    int ball_number;
    int player_num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // by default, all 1
        bg_number = 1;
        ball_number = 1;

        final Intent intent = getIntent();
        player_num = intent.getIntExtra("player_num",-1);

        final ImageView bg1 = (ImageView) this.findViewById(R.id.imageView5);
        bg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen background: Green", Toast.LENGTH_SHORT).show();
                bg_number = 1;
            }
        });

        final ImageView bg2 = (ImageView) this.findViewById(R.id.imageView6);
        bg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen background: Blue", Toast.LENGTH_SHORT).show();
                bg_number = 2;
            }
        });

        final ImageView bg3 = (ImageView) this.findViewById(R.id.imageView7);
        bg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen background: Yellow", Toast.LENGTH_SHORT).show();
                bg_number = 3;
            }
        });

        final ImageView bg4 = (ImageView) this.findViewById(R.id.imageView8);
        bg4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen background: Orange", Toast.LENGTH_SHORT).show();
                bg_number = 4;
            }
        });

        final ImageView ball1 = (ImageView) this.findViewById(R.id.imageView9);
        ball1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen ball: Blue", Toast.LENGTH_SHORT).show();
                ball_number = 1;
            }
        });

        final ImageView ball2 = (ImageView) this.findViewById(R.id.imageView11);
        ball2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen ball: White", Toast.LENGTH_SHORT).show();
                ball_number = 2;
            }
        });

        final ImageView ball3 = (ImageView) this.findViewById(R.id.imageView12);
        ball3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen ball: Pacman", Toast.LENGTH_SHORT).show();
                ball_number = 3;
            }
        });

        final ImageView ball4 = (ImageView) this.findViewById(R.id.imageView13);
        ball4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(settings.this, "Chosen ball: Poke Ball", Toast.LENGTH_SHORT).show();
                ball_number = 4;
            }
        });


        Button play = (Button) findViewById(R.id.button_play);
        play.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(settings.this, MainActivity.class);
                intent.putExtra("player_num",player_num);
                intent.putExtra("bg_num",bg_number);
                intent.putExtra("ball_num",ball_number);
                startActivity(intent);
                finish();
            }
        });



    }
}