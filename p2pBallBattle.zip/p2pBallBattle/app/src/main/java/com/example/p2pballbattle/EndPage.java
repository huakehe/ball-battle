package com.example.p2pballbattle;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;


public class EndPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        final Intent intent = getIntent();
        int status = intent.getIntExtra("status",2);



        ImageView imageView = findViewById(R.id.result);
        if(status==1){
            imageView.setImageResource(R.drawable.win);
        }
        if(status==0){
            imageView.setImageResource(R.drawable.lose);
        }

        Button button_restart = (Button) findViewById(R.id.restart_button);
        button_restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(EndPage.this, StartPage.class);
                startActivity(intent);
                finish();
            }
        });


        Button button_exit = (Button) findViewById(R.id.exit_button);
        button_exit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
//                onDestroy();
            }
        });

        // reset database
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
        Server ser = new Server(200,200,20,20,3,3);
        Map<String, Object> childUpdates = new HashMap<>();
        childUpdates.put("/Users/" + "Server", ser.toServerMap());
        mDatabase.updateChildren(childUpdates);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


}