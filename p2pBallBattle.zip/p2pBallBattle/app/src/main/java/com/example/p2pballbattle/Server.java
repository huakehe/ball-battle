package com.example.p2pballbattle;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class Server {
    private float server_x;
    private float server_y;
    public float server_radius;
    public float client_radius;

    public int getServer_score() {
        return server_score;
    }

    public void setServer_score(int server_score) {
        this.server_score = server_score;
    }

    public int getClient_score() {
        return client_score;
    }

    public void setClient_score(int client_score) {
        this.client_score = client_score;
    }

    public int server_score;
    public int client_score;

    public float getServer_x() {
        return server_x;
    }

    public void setServer_x(float server_x) {
        this.server_x = server_x;
    }

    public float getServer_y() {
        return server_y;
    }

    public void setServer_y(float server_y) {
        this.server_y = server_y;
    }

    public float getServer_radius() {
        return server_radius;
    }

    public void setServer_radius(float server_radius) {
        this.server_radius = server_radius;
    }

    public float getClient_radius() {
        return client_radius;
    }

    public void setClient_radius(float client_radius) {
        this.client_radius = client_radius;
    }


    public Server(float server_x, float server_y, float server_radius, float client_radius, int server_score, int client_score) {
        this.server_x = server_x;
        this.server_y = server_y;
        this.server_radius = server_radius;
        this.client_radius = client_radius;
        this.server_score = server_score;
        this.client_score = client_score;
    }


    public Server(){}

    @Exclude
    public Map<String, Object> toServerMap() {
        // To map function to setup key/values for JSON tree in database
        HashMap<String, Object> result = new HashMap<>();
        result.put("server_x", server_x);
        result.put("server_y", server_y);
        result.put("server_radius", server_radius);
        result.put("client_radius", client_radius);
        result.put("server_score", server_score);
        result.put("client_score", client_score);

        return result;
    }



}
