package com.example.p2pballbattle;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private static final String TAG = "MainActivity";
    private DatabaseReference mDatabase;
    private SensorManager mSensorManager;
    private Sensor mSensor;
    float[] gravity = new float[3];
    float[] linear_acceleration = new float[3];
    Bitmap bitmap;
    Bitmap workingBitmap;
    static {
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
    }


    // server
    float server_radius;
    float server_x;
    float server_y;
    int server_score;

    // client
    float client_radius;
    float client_x;
    float client_y;
    int client_score;


    String player_name;
    int host;

    float ballMass = 10.0f;
    float balRadius = 100.0f;
    double speed = 0.3; // range from 0 to 1
    ArrayList<Integer> target_x_list = new ArrayList<>(30);
    ArrayList<Integer> target_y_list = new ArrayList<>(30);
    ArrayList<Integer> trap_x_list = new ArrayList<>(15);
    ArrayList<Integer> trap_y_list = new ArrayList<>(15);


    float targetX;
    float targetY;
    float trapX;
    float trapY;

    float MaxX;
    float MaxY;
    int bg_num;
    int ball_num;



    static final int ACCELEROMETER_AXIS_SWAP[][] = {
            {1,-1,0,1},
            {-1,-1,1,0},
            {-1,1,0,1},
            {1,1,1,0}
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);  // lock rotation

        // get intent from start page
        final Intent intent = getIntent();
        int player_num = intent.getIntExtra("player_num",-1);
        bg_num = intent.getIntExtra("bg_num",-1);
        ball_num = intent.getIntExtra("ball_num",-1);


        server_score = 3;
        client_score = 3;
        server_radius = 20;
        client_radius = 20;
        server_x = 200;
        server_y = 200;
        client_x = 400;
        client_y = 400;

        if(player_num==1){

            host = 1;
            player_name = "Player 1";
        }

        if(player_num==2){

            host = 0;
            player_name = "Player 2";
        }

        mDatabase = FirebaseDatabase.getInstance().getReference();
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mSensorManager.registerListener(this, mSensor , SensorManager.SENSOR_DELAY_NORMAL);



        // Draw Canvas ( Initialization)
        BitmapFactory.Options myOptions = new BitmapFactory.Options();
        myOptions.inDither = true;
        myOptions.inScaled = true;
        myOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;// important
        myOptions.inPurgeable = true;

        // choose different backgrounds
        if(bg_num==1){
            bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bg);
        }
        if(bg_num==2){
            bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bg2);
        }
        if(bg_num==3){
            bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bg3);
        }
        if(bg_num==4){
            bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bg4);
        }


        Paint paint = new Paint();
        paint.setAntiAlias(true);

        workingBitmap = Bitmap.createBitmap(bitmap);
        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);

        ImageView imageView = (ImageView)findViewById(R.id.imageView);
        imageView.setAdjustViewBounds(true);
        imageView.setImageBitmap(mutableBitmap);

        MaxX = mutableBitmap.getWidth();
        MaxY = mutableBitmap.getHeight();


        int target_number = 30;
        int trap_number = 15;
        //added draw 30 targets
        final Random rand = new Random();
        for(int i=0;i<target_number;i++){
            target_x_list.add(rand.nextInt((int)(800)) + 1 +100);
            target_y_list.add(rand.nextInt((int)(500*0.8)) + 1 +100);
        }

        for(int i=0;i<trap_number;i++){
            trap_x_list.add(rand.nextInt((int)(800)) + 1 +100);
            trap_y_list.add(rand.nextInt((int)(500*0.8)) + 1 +100);
        }


        // Client - Get radius and toys info from Firebase
        if(host == 0) {
            DatabaseReference serverRef = FirebaseDatabase.getInstance().getReference("Users/Server"); // !!
            serverRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Server server = dataSnapshot.getValue(Server.class);
                    if (server != null) {
                        server_radius = server.getServer_radius();
                        client_radius = server.getClient_radius();
                        server_x = server.getServer_x();
                        server_y = server.getServer_y();
                        server_score = server.getServer_score();
                        client_score = server.getClient_score();
                    }
                    updateBitmap();
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
            DatabaseReference toyRef = FirebaseDatabase.getInstance().getReference("Users/Toys");
            toyRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    ToyLocation location = dataSnapshot.getValue(ToyLocation.class);

                    if(location!=null) {
                        for (int i = 0; i < target_x_list.size(); i++) {
                            target_x_list.set(i, location.target_x_list.get(i));
                            target_y_list.set(i, location.target_y_list.get(i));
                        }
                        for (int j = 0; j < trap_x_list.size(); j++) {
                            trap_x_list.set(j, location.trap_x_list.get(j));
                            trap_y_list.set(j, location.trap_y_list.get(j));
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Failed to read value
                    Log.w("Firebase", "Failed to read value.", databaseError.toException());
                }
            });
        }


        // Server
        if( host == 1) {
            DatabaseReference clientRef = FirebaseDatabase.getInstance().getReference("Users/Client");
            clientRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    Client client = dataSnapshot.getValue(Client.class);
                    if (client != null) {
                        client_x = client.getClient_x();
                        client_y = client.getClient_y();
                    }
                    updateBitmap();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Failed to read value
                    Log.w("Firebase", "Failed to read value.", databaseError.toException());
                }
            });
        }


    }

    public void updateBitmap(){

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.BLUE);

        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);


        Canvas canvas = new Canvas(mutableBitmap);
        Bitmap food = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.food);
        Bitmap bomb = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.bomb);
        Bitmap wall = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.wall);

        // different bitmap for balls
        Bitmap blue = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.blue); // ball 1
        Bitmap white = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.white); // ball 2
        Bitmap yellow = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.ball3);
        Bitmap red = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.ball4);
        Bitmap enemy = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.enemy);


        // draw your ball
        if(host==1) {
            if (ball_num == 1) {
                int left1 = (int) (server_x - server_radius - 7);
                int right1 = (int) (server_x + server_radius + 7);
                int top1 = (int) (server_y - server_radius - 7);
                int bottom1 = (int) (server_y + server_radius + 7);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(blue, null, destBounds1, null);
            }
            if (ball_num == 2) {
                int left1 = (int) (server_x - server_radius);
                int right1 = (int) (server_x + server_radius);
                int top1 = (int) (server_y - server_radius);
                int bottom1 = (int) (server_y + server_radius);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(white, null, destBounds1, null);
            }
            if (ball_num == 3) {
                int left1 = (int) (server_x - server_radius);
                int right1 = (int) (server_x + server_radius);
                int top1 = (int) (server_y - server_radius);
                int bottom1 = (int) (server_y + server_radius);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(yellow, null, destBounds1, null);
            }
            if (ball_num == 4) {
                int left1 = (int) (server_x - server_radius - 3);
                int right1 = (int) (server_x + server_radius + 3);
                int top1 = (int) (server_y - server_radius - 3);
                int bottom1 = (int) (server_y + server_radius + 3);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(red, null, destBounds1, null);
            }
        }
        else{
            if (ball_num == 1) {
                int left1 = (int) (client_x - client_radius - 7);
                int right1 = (int) (client_x + client_radius + 7);
                int top1 = (int) (client_y - client_radius - 7);
                int bottom1 = (int) (client_y + client_radius + 7);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(blue, null, destBounds1, null);
            }
            if (ball_num == 2) {
                int left1 = (int) (client_x - client_radius);
                int right1 = (int) (client_x + client_radius);
                int top1 = (int) (client_y - client_radius);
                int bottom1 = (int) (client_y + client_radius);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(white, null, destBounds1, null);
            }
            if (ball_num == 3) {
                int left1 = (int) (client_x - client_radius);
                int right1 = (int) (client_x + client_radius);
                int top1 = (int) (client_y - client_radius);
                int bottom1 = (int) (client_y + client_radius);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(yellow, null, destBounds1, null);
            }
            if (ball_num == 4) {
                int left1 = (int) (client_x - client_radius - 3);
                int right1 = (int) (client_x + client_radius + 3);
                int top1 = (int) (client_y - client_radius - 3);
                int bottom1 = (int) (client_y + client_radius + 3);
                Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
                canvas.drawBitmap(red, null, destBounds1, null);
            }
        }



        // draw opponent's ball
        if(host==1) {
            int left2 = (int) (client_x - client_radius);
            int right2 = (int) (client_x + client_radius);
            int top2 = (int) (client_y - client_radius);
            int bottom2 = (int) (client_y + client_radius);
            Rect destBounds2 = new Rect(left2, top2, right2, bottom2);
            canvas.drawBitmap(enemy, null, destBounds2, null);
        }
        else{
            int left1 = (int) (server_x - server_radius);
            int right1 = (int) (server_x + server_radius);
            int top1 = (int) (server_y - server_radius);
            int bottom1 = (int) (server_y + server_radius );
            Rect destBounds1 = new Rect(left1, top1, right1, bottom1);
            canvas.drawBitmap(enemy, null, destBounds1, null);
        }

        // draw foods
        for (int i = 0; i < target_x_list.size(); i++) {
            int left = target_x_list.get(i) - 7 - 100;
            int right = target_x_list.get(i) + 7 - 100;
            int top = target_y_list.get(i) - 7 - 100;
            int bottom = target_y_list.get(i) + 7 - 100;
            Rect destBounds = new Rect(left, top, right, bottom);
            canvas.drawBitmap(food, null, destBounds, null);
            //canvas.drawCircle(target_x_list.get(i), target_y_list.get(i), target_radius, paint);
        }


        // draw traps
//        paint.setColor(Color.BLACK);
        for (int i = 0; i < trap_x_list.size(); i++) {
            //canvas.drawCircle(trap_x_list.get(i), trap_y_list.get(i), trap_radius, paint);
            int left = trap_x_list.get(i) - 7 - 100;
            int right = trap_x_list.get(i) + 7 - 100;
            int top = trap_y_list.get(i) - 7 - 100;
            int bottom = trap_y_list.get(i) + 7 - 100;
            Rect destBounds = new Rect(left, top, right, bottom);
            canvas.drawBitmap(bomb, null, destBounds, null);
        }
//        paint.setColor(Color.BLUE);

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setAdjustViewBounds(true);
        imageView.setImageBitmap(mutableBitmap);

        TextView textView = (TextView) findViewById(R.id.textView);
        if(host==1){
            if(server_score==3){
                textView.setText("  "+player_name + "                       Radius:" + server_radius + "                       Life Remained: ❤️❤️❤️" );

            }
            if(server_score==2){
                textView.setText("  "+player_name + "                       Radius:" + server_radius + "                       Life Remained: ❤️❤️️" );

            }
            if(server_score==1){
                textView.setText("  "+player_name + "                       Radius:" + server_radius + "                       Life Remained: ❤️️️" );
            }

        }
        if(host==0){
            if(client_score==3){
                textView.setText("  "+player_name + "                       Radius:" + client_radius + "                       Life Remained: ❤️❤️❤️" );
            }
            if(client_score==2){
                textView.setText("  "+player_name + "                       Radius:" + client_radius + "                       Life Remained: ❤️❤️️" );
            }
            if(client_score==1){
                textView.setText("  "+player_name + "                       Radius:" + client_radius + "                       Life Remained: ❤️" );
            }


        }

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        final float alpha = 0.8f;
        final Random rand = new Random();

        final int [] as = ACCELEROMETER_AXIS_SWAP[3];

        float screenX = (float) -as[0] * event.values[as[2]];
        float screenY = (float) as[1] * event.values[as[3]];
        float screenZ = event.values[2];


        // Isolate the force of gravity with the low-pass filter.
        gravity[0] = alpha * gravity[0] + (1 - alpha) * screenX;
        gravity[1] = alpha * gravity[1] + (1 - alpha) * screenY;
        gravity[2] = alpha * gravity[2] + (1 - alpha) * screenZ;

        // Remove the gravity contribution with the high-pass filter.
        linear_acceleration[0] = screenX - gravity[0];
        linear_acceleration[1] = screenY - gravity[1];
        linear_acceleration[2] = screenZ - gravity[2];



        // host
        if(host == 1) {
            //only update ball location when ball is within the screen boundaries
            if (balRadius + server_x - speed * gravity[0] * ballMass > 100 && balRadius + server_x - speed * gravity[0] * ballMass < MaxX + 100) {
                server_x += speed * (-gravity[0] * ballMass);
            }
            if (balRadius + server_y + speed * gravity[1] * ballMass > 100 && balRadius + server_y + speed * gravity[1] * ballMass < MaxY + 100) {
                server_y += speed * (gravity[1] * ballMass);
            }
        } else{ // client
            if (balRadius + client_x - speed * gravity[0] * ballMass > 100 && balRadius + client_x - speed * gravity[0] * ballMass < MaxX + 100) {
                client_x += speed * (-gravity[0] * ballMass);
            }
            if (balRadius + client_y + speed * gravity[1] * ballMass > 100 && balRadius + client_y + speed * gravity[1] * ballMass < MaxY + 100) {
                client_y += speed * (gravity[1] * ballMass);
            }
        }


        for(int j=0;j<target_x_list.size();j++){
            // if server touch target
            if(Math.abs(balRadius+ server_x -target_x_list.get(j))<20&&Math.abs(balRadius+ server_y -target_y_list.get(j))<20){
                // remove eaten food
                target_x_list.remove(j);
                target_y_list.remove(j);

                // create new food after one is removed
                targetX = rand.nextInt((int)(1000)) + 1;
                targetY = rand.nextInt((int)(500*0.8)) + 1;
                target_x_list.add((int)targetX +100);
                target_y_list.add((int)targetY +100);
                server_radius += 1;

                if(server_radius>50){
                    server_radius=10;
                }
            }
            // if client touch target
            if(Math.abs(balRadius+ client_x -target_x_list.get(j))<20&&Math.abs(balRadius+ client_y -target_y_list.get(j))<20){

                // remove old trap
                target_x_list.remove(j);
                target_y_list.remove(j);

                // add new trap
                targetX = rand.nextInt((int)(1000)) + 1;
                targetY = rand.nextInt((int)(500*0.8)) + 1;
                target_x_list.add((int)targetX +100);
                target_y_list.add((int)targetY +100);
                client_radius += 1;
                if(client_radius >50){
                    client_radius=50;
                }
            }
        }
        for(int k=0;k<trap_x_list.size();k++){
            // if server touch trap
            if(Math.abs(balRadius+ server_x -trap_x_list.get(k))<20&&Math.abs(balRadius+ server_y -trap_y_list.get(k))<20){

                // remove old trap
                trap_x_list.remove(k);
                trap_y_list.remove(k);

                // add new trap
                trapX = rand.nextInt((int)(1000)) + 1;
                trapY = rand.nextInt((int)(500*0.8)) + 1;
                trap_x_list.add((int)trapX +100);
                trap_y_list.add((int)trapY +100);
                server_radius -=5;


                if(server_radius <20){
                    server_radius =20;
                }
            }
            // if client touch trap
            if(Math.abs(balRadius+ client_x -trap_x_list.get(k))<20&&Math.abs(balRadius+ client_y -trap_y_list.get(k))<20){

                // remove old trap
                trap_x_list.remove(k);
                trap_y_list.remove(k);

                // add new trap
                trapX = rand.nextInt((int)(1000)) + 1;
                trapY = rand.nextInt((int)(500*0.8)) + 1;
                trap_x_list.add((int)trapX +100);
                trap_y_list.add((int)trapY +100);
                client_radius -=5;


                if(client_radius <20){
                    client_radius =20;
                }
            }
        }


        // Collision cases
        if((Math.pow(server_x - client_x,2)+Math.pow(server_y - client_y,2))<Math.pow(server_radius + client_radius,2)){
            server_x = 600;
            server_y = 200;
            client_x = 500;
            client_y = 300;
            if(server_radius < client_radius){
                //Toast.makeText(getApplicationContext(), "Server life -1. Server Score: "+(server_score-1), Toast.LENGTH_SHORT).show();
                server_score -= 1;
                server_radius = 20;
//                Server ser1 = new Server(server_x,server_y,server_radius,client_radius,server_score-1,client_score);
//                Map<String, Object> childUpdates1 = new HashMap<>();
//                childUpdates1.put("/Users/" + "Server", ser1.toServerMap());
//                mDatabase.updateChildren(childUpdates1);

                if(server_score < 1){
//                    Toast.makeText(getApplicationContext(), "Server Lost. Client score: "+(client_score), Toast.LENGTH_LONG).show();
                }
            }
            if(server_radius > client_radius){
                //Toast.makeText(getApplicationContext(), "Client life -1. Client Score: " + (client_score-1), Toast.LENGTH_SHORT).show();
                client_score -=1;
                client_radius = 20;
                if(client_score < 1){
//                    Toast.makeText(getApplicationContext(), "Client Lost. Server score: " + (server_score), Toast.LENGTH_LONG).show();
                }
            }
        }

        if(host == 1)
        {
            if(client_score == 0){
                Intent intent = new Intent(MainActivity.this, EndPage.class);
                intent.putExtra("status",1); // win is 1, lose is 0
                startActivity(intent);
                finish();
            }
            if(server_score == 0){
                Intent intent = new Intent(MainActivity.this, EndPage.class);
                intent.putExtra("status",0); // win is 1, lose is 0
                startActivity(intent);
                finish();
            }

        } else {
            if(client_score == 0){
                Intent intent = new Intent(MainActivity.this, EndPage.class);
                intent.putExtra("status",0); // win is 1, lose is 0
                startActivity(intent);
                finish();
            }
            if(server_score == 0){
                Intent intent = new Intent(MainActivity.this, EndPage.class);
                intent.putExtra("status",1); // win is 1, lose is 0
                startActivity(intent);
                finish();
            }


        }



        // push to firebase
        ToyLocation tloc = new ToyLocation(target_x_list,target_y_list,trap_x_list,trap_y_list);
        Server ser = new Server(server_x,server_y,server_radius,client_radius,server_score,client_score);
        Client cli = new Client(client_x,client_y);

        Map<String, Object> childUpdates = new HashMap<>();

        if(host==1){
            childUpdates.put("/Users/" + "Toys", tloc.toToyMap());
            childUpdates.put("/Users/" + "Server", ser.toServerMap());
        }else{
            childUpdates.put("/Users/" + "Client", cli.toClientMap());
        }

        mDatabase.updateChildren(childUpdates)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Toast to inform user that database update was successful
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Toast to inform user that database update was failed
                        Log.e("Firebase", e.toString());
                        // Toast.makeText(getApplicationContext(), "Database update FAILED", Toast.LENGTH_SHORT).show();
                    }
                });


    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }



}